package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.data.model.Alumno;
import com.example.myapplication.data.model.BaseDatos;
import com.example.myapplication.data.model.Matricula;

public class RegistroNota extends AppCompatActivity {
TextView nombre;
TextView cedulaRegistro;
TextView email;
EditText nota;
Matricula matricula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_nota);

        Intent i = getIntent();
        final String numero = i.getStringExtra("numero");
        final String cedula = i.getStringExtra("cedula");
        nombre = findViewById(R.id.nombreRegistro);
        cedulaRegistro = findViewById(R.id.cedulaRegistro);
        email = findViewById(R.id.emailRegistro);
        nota = findViewById(R.id.notaRegistrada);
        matricula = BaseDatos.getMatriculaByAlumnoByGrupo(cedula, numero);
        Alumno alumno = BaseDatos.alumnoById(cedula);
        nombre.setText(alumno.getNombre());
        cedulaRegistro.setText(alumno.getCedula());
        email.setText(alumno.getEmail());
        nota.setText(String.valueOf(matricula.getNota()));
    }

    public void registrarNota(View v){
        String no = nota.getText().toString();
        BaseDatos.setNota(matricula, Float.parseFloat(no));
        this.finish();
    }
}
