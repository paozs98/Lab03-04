package com.example.myapplication.data.model;

import java.util.ArrayList;

public class BaseDatos {
    static public String loggedInProffessor = "";

    static public ArrayList<Grupo> grupos = new ArrayList<Grupo>();
    static public ArrayList<Profesor> profesores = new ArrayList<Profesor>();
    static public ArrayList<Alumno> alumnos = new ArrayList<Alumno>();
    static public ArrayList<Matricula> matriculas = new ArrayList<Matricula>();

    static public void addGrupos(){
        grupos.add(new Grupo("1", "10am", "111"));
        grupos.add(new Grupo("2", "12pm", "111"));
        grupos.add(new Grupo("3", "12pm", "222"));

        profesores.add(new Profesor("111", "Juan", "juan.com", "111"));
        profesores.add(new Profesor("222", "Maria", "maria.com", "222"));

        alumnos.add(new Alumno("333", "Pedro", "pedro.com"));
        alumnos.add(new Alumno("444", "Lara", "lara.com"));
        alumnos.add(new Alumno("555", "Ana", "ana.com"));
        alumnos.add(new Alumno("666", "Laura", "laura.com"));
        alumnos.add(new Alumno("777", "Magda", "magda.com"));
        alumnos.add(new Alumno("888", "Jairo", "jairo.com"));

        matriculas.add(new Matricula("1", "333", 0));
        matriculas.add(new Matricula("1", "444", 0));
        matriculas.add(new Matricula("1", "555", 0));
        matriculas.add(new Matricula("1", "666", 0));
        matriculas.add(new Matricula("1", "777", 0));
        matriculas.add(new Matricula("2", "888", 0));
        matriculas.add(new Matricula("2", "666", 0));
        matriculas.add(new Matricula("2", "777", 0));
        matriculas.add(new Matricula("3", "333", 0));
        matriculas.add(new Matricula("3", "444", 0));
        matriculas.add(new Matricula("3", "555", 0));
    }
    static public boolean isUser(String ced,String con){
        for(Profesor p: profesores){
            if(p.isUser(ced,con) == true){
                return true;
            }
        }
        return false;
    }

    static public void setLoggedInProffessor(String ced){
        loggedInProffessor = ced;
    }

    static public Alumno alumnoById(String cedula){
        for (Alumno g: alumnos) {
            if(g.getCedula().equals(cedula)){
                return g;
            }
        }
        return null;
    }

    static public float getNotaByAlumnoByGrupo(String cedula, String numero){
        for (Matricula g: matriculas) {
            if(g.getCedulaAlumno().equals(cedula) && g.getNumeroGrupo().equals(numero)){
                return g.getNota();
            }
        }
        return 0;
    }

    static public Matricula getMatriculaByAlumnoByGrupo(String cedula, String numero){
        for (Matricula g: matriculas) {
            if(g.getCedulaAlumno().equals(cedula) && g.getNumeroGrupo().equals(numero)){
                return g;
            }
        }
        return null;
    }

    static public ArrayList<Grupo> gruposByProfesor(){
        ArrayList<Grupo> gru = new ArrayList<Grupo>();
        for (Grupo g: grupos) {
            if(g.getProfesor().equals(loggedInProffessor)){
                gru.add(g);
            }
        }
        return gru;
    }

    static public ArrayList<Alumno> estudiantesPorGrupo(String grup){
        ArrayList<Alumno> gru = new ArrayList<Alumno>();
        for (Matricula a: matriculas) {
            if(a.getNumeroGrupo().equals(grup)){

                gru.add(alumnoById(a.getCedulaAlumno()));
            }
        }
        return gru;
    }

    static public void setNota(Matricula m, float nota){
        m.setNota(nota);
    }
}
