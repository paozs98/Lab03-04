package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.myapplication.data.model.BaseDatos;
import com.example.myapplication.ui.AlumnoAdapter;

public class Alumnos extends AppCompatActivity {
    RecyclerView recyclerView;
    AlumnoAdapter adapter;
    String numero;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumnos);
        Intent i = getIntent();
        numero = i.getStringExtra("numero");
        recyclerView = this.findViewById(R.id.recyclerViewAlumno);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new AlumnoAdapter(BaseDatos.estudiantesPorGrupo(numero), numero);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), RegistroNota.class);
                i.putExtra("cedula", BaseDatos.estudiantesPorGrupo(numero).get(recyclerView.getChildAdapterPosition(v)).getCedula());
                i.putExtra("numero", numero);
                v.getContext().startActivity(i);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        adapter = new AlumnoAdapter(BaseDatos.estudiantesPorGrupo(numero), numero);
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), RegistroNota.class);
                i.putExtra("cedula", BaseDatos.estudiantesPorGrupo(numero).get(recyclerView.getChildAdapterPosition(v)).getCedula());
                i.putExtra("numero", numero);
                v.getContext().startActivity(i);
            }
        });
        recyclerView.setAdapter(adapter);
        super.onResume();
    }
}
