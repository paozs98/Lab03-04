package com.example.myapplication.data.model;

public class Matricula {
    private String numeroGrupo;
    private String cedulaAlumno;
    private float nota;

    public Matricula (String numero, String cedula, float no) {
        this.numeroGrupo = numero;
        this.cedulaAlumno = cedula;
        this.nota = no;
    }

    public void setNota(float n) {
        this.nota = n;
    }

    public String getNumeroGrupo() {
        return numeroGrupo;
    }

    public String getCedulaAlumno(){
        return cedulaAlumno;
    }

    public float getNota() {
        return nota;
    }
}
