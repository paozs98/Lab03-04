package com.example.myapplication.data.model;

public class Profesor {
    private String cedula;
    private String nombre;
    private String email;
    private String contrasena;

    public Profesor () {
        cedula = "";
        nombre = "";
        email = "";
        contrasena = "";
    }
    public Profesor (String c, String n, String e, String contra) {
        cedula = c;
        nombre = n;
        email = e;
        contrasena = contra;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public boolean isUser(String ced, String cont) {
        if(this.getCedula().equals(ced) && this.contrasena.equals(cont)){
            return  true;
        }
        else {
            return false;
        }
    }
}
