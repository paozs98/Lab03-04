package com.example.myapplication.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.data.model.Grupo;

import java.util.ArrayList;

public class GrupoAdapter extends RecyclerView.Adapter<GrupoAdapter.ViewHolder>
implements RecyclerView.OnClickListener{
    RecyclerView.OnClickListener listener;
    ArrayList<Grupo> grupos;

    public GrupoAdapter(ArrayList<Grupo> grupos) {
        this.grupos = grupos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutId = R.layout.list_item;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        boolean attached = false;
        View v = layoutInflater.inflate(layoutId, parent, attached);
        v.setOnClickListener(this);
        ViewHolder viewHolder = new ViewHolder(v);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(grupos.get(position));
    }

    @Override
    public int getItemCount() {
        return grupos.size();
    }

    public void setOnClickListener(RecyclerView.OnClickListener list){
        this.listener = list;
    }
    @Override
    public void onClick(View v) {
        if(listener != null){
            listener.onClick(v);
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView numero;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            numero = itemView.findViewById(R.id.cedulaRegistro);
        }

        public void bind(Grupo grupo) {
            this.numero.setText(grupo.getNumero());
        }
    }
}
