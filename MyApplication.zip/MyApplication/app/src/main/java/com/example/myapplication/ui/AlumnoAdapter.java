package com.example.myapplication.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.data.model.Alumno;
import com.example.myapplication.data.model.BaseDatos;

import java.util.ArrayList;

public class AlumnoAdapter extends RecyclerView.Adapter<AlumnoAdapter.ViewHolder>implements RecyclerView.OnClickListener{
    RecyclerView.OnClickListener listener;
    ArrayList<Alumno> alumnos;
    String numeroGrupo;

    public AlumnoAdapter(ArrayList<Alumno> alumnos, String numeroGrupo) {
        this.numeroGrupo = numeroGrupo;
        this.alumnos = alumnos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutId = R.layout.alumno_item;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        boolean attached = false;
        View v = layoutInflater.inflate(layoutId, parent, attached);
        v.setOnClickListener(this);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(alumnos.get(position));
    }

    @Override
    public int getItemCount() {
        return alumnos.size();
    }
    public void setOnClickListener(RecyclerView.OnClickListener list){
        this.listener = list;
    }
    @Override
    public void onClick(View v) {
        if(listener != null){
            listener.onClick(v);
        }
    }
    class ViewHolder extends RecyclerView.ViewHolder{
        TextView nombre;
        TextView cedula;
        TextView nota;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cedula = itemView.findViewById(R.id.cedulaRegistro);
            nombre = itemView.findViewById(R.id.nombreRegistro);
            nota = itemView.findViewById(R.id.nota);
        }

        public void bind(Alumno alumno) {
            this.cedula.setText(alumno.getCedula());
            this.nombre.setText(alumno.getNombre());
            String s = String.valueOf(BaseDatos.getNotaByAlumnoByGrupo(alumno.getCedula(),numeroGrupo));
            this.nota.setText(s);
        }

    }
}
