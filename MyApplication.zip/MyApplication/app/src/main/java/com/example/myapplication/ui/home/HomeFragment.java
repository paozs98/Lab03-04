package com.example.myapplication.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Alumnos;
import com.example.myapplication.R;
import com.example.myapplication.data.model.Alumno;
import com.example.myapplication.data.model.BaseDatos;
import com.example.myapplication.data.model.Grupo;
import com.example.myapplication.ui.GrupoAdapter;

public class HomeFragment extends Fragment {

 RecyclerView recyclerView;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView = root.findViewById(R.id.recyclerView);
        recyclerView.addItemDecoration(new DividerItemDecoration(root.getContext(), DividerItemDecoration.VERTICAL));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(root.getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        GrupoAdapter adapter = new GrupoAdapter(BaseDatos.gruposByProfesor());
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), Alumnos.class);
                i.putExtra("numero", BaseDatos.grupos.get(recyclerView.getChildAdapterPosition(v)).getNumero());
                v.getContext().startActivity(i);
            }
        });
        recyclerView.setAdapter(adapter);
        return root;
    }

}
