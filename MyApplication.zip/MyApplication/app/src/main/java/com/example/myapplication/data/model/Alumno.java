package com.example.myapplication.data.model;

public class Alumno {
    private String cedula;
    private String nombre;
    private String email;

    public Alumno (String c, String n, String e) {
        cedula = c;
        nombre = n;
        email = e;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
}
