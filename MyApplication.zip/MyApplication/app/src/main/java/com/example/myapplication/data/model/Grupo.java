package com.example.myapplication.data.model;

public class Grupo {
    private String numero;
    private String horario;
    private String profesor;

    public Grupo (String n, String h, String p) {
        numero = n;
        horario = h;
        profesor = p;
    }

    public String getNumero() {
        return numero;
    }

    public String getHorario() {
        return horario;
    }

    public String getProfesor() {
        return profesor;
    }
}
